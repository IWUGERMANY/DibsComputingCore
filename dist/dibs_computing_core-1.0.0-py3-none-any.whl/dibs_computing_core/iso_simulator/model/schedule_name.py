class ScheduleName:
    def __init__(self, People: float, Appliances: float):
        self.People = People
        self.Appliances = Appliances
